package com.mvpify.app

import com.mvpify.app.data.SortBy
import com.mvpify.app.data.Track
import com.mvpify.app.data.TrackOps
import org.junit.Assert.assertEquals
import org.junit.Test

class TrackOpsTest {
    private fun t(id: String, title: String, artist: String = "A", album: String = "X", no: Int = 0, added: Long = 0, file: String = "$title.mp3") =
        Track(id, title, artist, album, 1000, no, added, file, null)

    @Test fun sortByTitleIgnoresCase() {
        val r = TrackOps.sort(listOf(t("1", "banana"), t("2", "Apple")), SortBy.TITLE)
        assertEquals(listOf("2", "1"), r.map { it.id })
    }

    @Test fun sortByDateNewestFirst() {
        val r = TrackOps.sort(listOf(t("1", "a", added = 5), t("2", "b", added = 9)), SortBy.DATE)
        assertEquals("2", r.first().id)
    }

    @Test fun searchMatchesFilenameArtistAlbum() {
        val l = listOf(t("1", "Song", artist = "Daft", file = "zzz.flac"), t("2", "Other", album = "Discovery"))
        assertEquals(listOf("1"), TrackOps.search(l, "ZZZ").map { it.id })
        assertEquals(listOf("1"), TrackOps.search(l, "daft").map { it.id })
        assertEquals(listOf("2"), TrackOps.search(l, "discov").map { it.id })
        assertEquals(0, TrackOps.search(l, "  ").size)
    }

    @Test fun albumsOrderedByTrackNumber() {
        val a = TrackOps.albums(listOf(t("1", "b", album = "X", no = 2), t("2", "a", album = "X", no = 1)))
        assertEquals(listOf("2", "1"), a.getValue("X").map { it.id })
    }

    @Test fun formatTime() {
        assertEquals("1:05", TrackOps.formatTime(65_000))
        assertEquals("1:01:01", TrackOps.formatTime(3_661_000))
        assertEquals("0:00", TrackOps.formatTime(-5))
    }
}
