package com.mvpify.app.ui

import android.content.Context
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.mvpify.app.data.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.media3.common.Player
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlaying(onClose: () -> Unit) {
    val env = LocalEnv.current; val lib = env.lib; val pc = env.pc
    val ctx = LocalContext.current
    val id by pc.currentId.collectAsState()
    val playing by pc.isPlaying.collectAsState()
    val shuffle by pc.shuffle.collectAsState()
    val repeat by pc.repeat.collectAsState()
    val queue by pc.queue.collectAsState()
    val favs by lib.favourites.collectAsState()
    val tracks by lib.tracks.collectAsState()
    val t = id?.let { lib.byId[it] }
    var showQueue by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragPos by remember { mutableFloatStateOf(0f) }
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat()
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }

    LaunchedEffect(Unit) {
        while (true) {
            if (!dragging) pos = pc.position()
            dur = pc.duration().takeIf { it > 0 } ?: (lib.byId[pc.currentId.value]?.durationMs ?: 0L)
            vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
            delay(400)
        }
    }
    BackHandler(showQueue) { showQueue = false }

    val sliderColors = SliderDefaults.colors(thumbColor = MvpRed, activeTrackColor = MvpRed,
        inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant)

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.KeyboardArrowDown, "Close", Modifier.size(32.dp)) }
            Spacer(Modifier.weight(1f))
            Text("Now Playing", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { showQueue = true }) { Icon(Icons.Default.QueueMusic, "Queue") }
        }
        Spacer(Modifier.height(12.dp))
        Art(t?.artPath, Modifier.fillMaxWidth().aspectRatio(1f), 800, 20.dp)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t?.title ?: "Nothing playing", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(t?.artist ?: "", color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (t != null) IconButton(onClick = { lib.toggleFavourite(t.id) }) {
                val fav = t.id in favs
                Icon(if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favourite", tint = if (fav) MvpRed else LocalContentColor.current)
            }
        }
        Slider(
            value = (if (dragging) dragPos else pos.toFloat()).coerceIn(0f, maxOf(dur, 1L).toFloat()),
            onValueChange = { dragging = true; dragPos = it },
            onValueChangeFinished = { pc.seekTo(dragPos.toLong()); pos = dragPos.toLong(); dragging = false },
            valueRange = 0f..maxOf(dur, 1L).toFloat(), colors = sliderColors
        )
        Row(Modifier.fillMaxWidth()) {
            Text(TrackOps.formatTime(if (dragging) dragPos.toLong() else pos), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(TrackOps.formatTime(dur), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { pc.toggleShuffle() }) {
                Icon(Icons.Default.Shuffle, "Shuffle", tint = if (shuffle) MvpRed else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { pc.previous() }, Modifier.size(56.dp)) { Icon(Icons.Default.SkipPrevious, "Previous", Modifier.size(36.dp)) }
            FilledIconButton(onClick = { pc.toggle() }, Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = MvpRed, contentColor = Color.White)) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", Modifier.size(40.dp))
            }
            IconButton(onClick = { pc.next() }, Modifier.size(56.dp)) { Icon(Icons.Default.SkipNext, "Next", Modifier.size(36.dp)) }
            IconButton(onClick = { pc.cycleRepeat() }) {
                Icon(if (repeat == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat, "Repeat",
                    tint = if (repeat == Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.onSurfaceVariant else MvpRed)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.VolumeUp, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(vol, { vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0) },
                valueRange = 0f..maxVol, steps = (maxVol.toInt() - 1).coerceAtLeast(0), colors = sliderColors)
        }
        Spacer(Modifier.height(16.dp))
    }

    if (showQueue) ModalBottomSheet(onDismissRequest = { showQueue = false }, containerColor = MaterialTheme.colorScheme.surface) {
        Text("Queue (${queue.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.fillMaxWidth()) {
            itemsIndexed(queue, key = { i, q -> "$q#$i" }) { i, qid ->
                val q = lib.byId[qid]
                Row(Modifier.fillMaxWidth().clickable { pc.skipTo(i) }.padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Art(q?.artPath, Modifier.size(40.dp), 128)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(q?.title ?: "Unavailable file", maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (qid == id) MvpRed else MaterialTheme.colorScheme.onBackground)
                        Text(q?.artist ?: "", maxLines = 1, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { pc.removeFromQueue(i) }) { Icon(Icons.Default.Close, "Remove") }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
