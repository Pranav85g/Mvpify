package com.mvpify.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.ui.graphics.drawscope.Stroke
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.Image
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.mvpify.app.data.*
import com.mvpify.app.playback.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class Env(val lib: Library, val pc: PlayerController)
val LocalEnv = staticCompositionLocalOf<Env> { error("Env missing") }

sealed interface Route {
    data class Album(val name: String) : Route
    data class Artist(val name: String) : Route
    data class Playlist(val id: String) : Route
    data object Favs : Route
    data object Search : Route
    data object Settings : Route
}

class Nav(val push: (Route) -> Unit, val pop: () -> Unit, val openNow: () -> Unit)
val LocalNav = staticCompositionLocalOf<Nav> { error("Nav missing") }

object ArtCache {
    private val cache = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    suspend fun get(path: String, target: Int): Bitmap? {
        val key = "$path@$target"
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, o)
                var s = 1
                while (o.outWidth / (s * 2) >= target) s *= 2
                BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })?.also { cache.put(key, it) }
            } catch (e: Exception) { null }
        }
    }
}

@Composable
fun Art(path: String?, modifier: Modifier = Modifier, target: Int = 256, radius: Dp = 8.dp) {
    val bmp by produceState<Bitmap?>(null, path) { value = if (path == null) null else ArtCache.get(path, target) }
    Box(
        modifier.clip(RoundedCornerShape(radius)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun Header(title: String, back: Boolean = false, actions: @Composable RowScope.() -> Unit = {}) {
    val nav = LocalNav.current
    Row(
        Modifier.fillMaxWidth().padding(start = if (back) 4.dp else 16.dp, end = 4.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back) IconButton(onClick = nav.pop) { Icon(Icons.Default.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        actions()
    }
}

@Composable
fun SectionTitle(text: String, onMore: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (onMore != null) TextButton(onClick = onMore) { Text("See all", color = MvpRed) }
    }
}

@Composable
fun MediaCard(title: String, subtitle: String, art: String?, onClick: () -> Unit, modifier: Modifier = Modifier.width(132.dp)) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(4.dp)) {
        Art(art, Modifier.fillMaxWidth().aspectRatio(1f), 256, 12.dp)
        Spacer(Modifier.height(6.dp))
        Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun NameDialog(title: String, initial: String, confirm: String, onDone: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true, placeholder = { Text("Name") }) },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onDone(text) }) { Text(confirm, color = MvpRed) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddToPlaylistDialog(trackId: String, onDismiss: () -> Unit) {
    val lib = LocalEnv.current.lib
    val playlists by lib.playlists.collectAsState()
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        NameDialog("New playlist", "", "Create", { lib.addToPlaylist(lib.createPlaylist(it), trackId); onDismiss() }, onDismiss)
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to playlist") },
        text = {
            LazyColumn {
                item { TextButton(onClick = { creating = true }) { Icon(Icons.Default.Add, null, tint = MvpRed); Spacer(Modifier.width(8.dp)); Text("New playlist", color = MvpRed) } }
                items(playlists, key = { it.id }) { p ->
                    Text(p.name, Modifier.fillMaxWidth().clickable { lib.addToPlaylist(p.id, trackId); onDismiss() }.padding(vertical = 12.dp))
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun TrackRow(track: Track, list: List<Track>, index: Int, playlistId: String? = null, trailing: (@Composable () -> Unit)? = null) {
    val env = LocalEnv.current; val lib = env.lib; val pc = env.pc
    val ctx = LocalContext.current
    val cur by pc.currentId.collectAsState()
    val favs by lib.favourites.collectAsState()
    var menu by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable { pc.tap(list, index, lib.tapPlaysList.value) }.padding(start = 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(track.artPath, Modifier.size(48.dp), 128)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (cur == track.id) MvpRed else MaterialTheme.colorScheme.onBackground)
            Text("${track.artist} • ${TrackOps.formatTime(track.durationMs)}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing?.invoke()
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Play next") }, onClick = { pc.playNext(track); menu = false; Toast.makeText(ctx, "Playing next", Toast.LENGTH_SHORT).show() })
                DropdownMenuItem(text = { Text("Add to queue") }, onClick = { pc.addToQueue(track); menu = false; Toast.makeText(ctx, "Added to queue", Toast.LENGTH_SHORT).show() })
                DropdownMenuItem(text = { Text(if (track.id in favs) "Remove from favourites" else "Add to favourites") },
                    onClick = { lib.toggleFavourite(track.id); menu = false })
                DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { addDialog = true; menu = false })
                if (playlistId != null) DropdownMenuItem(text = { Text("Remove from this playlist") },
                    onClick = { lib.removeFromPlaylist(playlistId, track.id); menu = false })
            }
        }
    }
    if (addDialog) AddToPlaylistDialog(track.id) { addDialog = false }
}

fun LazyListScope.trackItems(tracks: List<Track>, playlistId: String? = null) {
    itemsIndexed(tracks, key = { i, t -> "${t.id}#$i" }) { i, t -> TrackRow(t, tracks, i, playlistId) }
}

@Composable
fun MiniPlayer() {
    val env = LocalEnv.current; val pc = env.pc; val nav = LocalNav.current
    val id by pc.currentId.collectAsState()
    val playing by pc.isPlaying.collectAsState()
    val tracks by env.lib.tracks.collectAsState()
    val t = id?.let { env.lib.byId[it] } ?: return
    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(id) {
        while (true) {
            val d = pc.duration(); progress = if (d > 0) (pc.position().toFloat() / d).coerceIn(0f, 1f) else 0f
            delay(500)
        }
    }
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth().clickable { nav.openNow() }) {
        Column {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Art(t.artPath, Modifier.size(44.dp), 128)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { pc.toggle() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause") }
                IconButton(onClick = { pc.next() }) { Icon(Icons.Default.SkipNext, "Next") }
            }
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(2.dp),
                color = MvpRed, trackColor = MaterialTheme.colorScheme.surfaceVariant)
        }
    }
}

/** MVPify logo: red disc with three white sound-wave arcs. */
@Composable
fun MvpLogo(dp: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(dp)) {
        val s = this.size.minDimension
        drawCircle(MvpRed)
        fun arc(x0: Float, y0: Float, cx: Float, cy: Float, x1: Float, y1: Float, w: Float) {
            val p = Path().apply { moveTo(x0 * s, y0 * s); quadraticBezierTo(cx * s, cy * s, x1 * s, y1 * s) }
            drawPath(p, Color.White, style = Stroke(width = w * s, cap = StrokeCap.Round))
        }
        arc(0.25f, 0.36f, 0.50f, 0.27f, 0.75f, 0.39f, 0.075f)
        arc(0.30f, 0.52f, 0.50f, 0.44f, 0.70f, 0.54f, 0.062f)
        arc(0.34f, 0.66f, 0.50f, 0.60f, 0.66f, 0.68f, 0.050f)
    }
}
