package com.mvpify.app.ui

import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalContext
import androidx.compose.animation.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.mvpify.app.data.*

@Composable
fun TabActions() {
    val nav = LocalNav.current
    IconButton(onClick = { nav.push(Route.Search) }) { Icon(Icons.Default.Search, "Search") }
    IconButton(onClick = { nav.push(Route.Settings) }) { Icon(Icons.Default.Settings, "Settings") }
}

@Composable
fun Empty(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

fun albumArt(tracks: List<Track>) = tracks.firstNotNullOfOrNull { it.artPath }

// ---------------- Home ----------------
@Composable
fun HomeScreen() {
    val env = LocalEnv.current; val lib = env.lib; val pc = env.pc; val nav = LocalNav.current
    val tracks by lib.tracks.collectAsState()
    val recents by lib.recents.collectAsState()
    val favs by lib.favourites.collectAsState()
    val playlists by lib.playlists.collectAsState()
    val recentTracks = remember(recents, tracks) { recents.mapNotNull { lib.byId[it] }.take(15) }
    val albums = remember(tracks) { TrackOps.albums(tracks) }
    val recentAlbums = remember(recentTracks) { recentTracks.map { it.album }.distinct().take(10) }
    val favTracks = remember(favs, tracks) { tracks.filter { it.id in favs } }
    val added = remember(tracks) { tracks.sortedByDescending { it.addedAt }.take(15) }
    Column(Modifier.fillMaxSize()) {
        Header("MVPify") { TabActions() }
        if (tracks.isEmpty()) { Empty("No songs yet. Use Settings → Rescan or change the music folder."); return@Column }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Button(onClick = { pc.playShuffled(tracks) }, colors = ButtonDefaults.buttonColors(containerColor = MvpRed, contentColor = Color.White)) {
                        Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(8.dp)); Text("Shuffle all")
                    }
                }
            }
            if (recentTracks.isNotEmpty()) item {
                SectionTitle("Recently played tracks")
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                    itemsIndexed(recentTracks) { i, t -> MediaCard(t.title, t.artist, t.artPath, { pc.play(recentTracks, i) }) }
                }
            }
            if (recentAlbums.isNotEmpty()) item {
                SectionTitle("Recently played albums")
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                    items(recentAlbums) { a ->
                        val l = albums[a].orEmpty()
                        MediaCard(a, l.firstOrNull()?.artist ?: "", albumArt(l), { nav.push(Route.Album(a)) })
                    }
                }
            }
            if (favTracks.isNotEmpty()) item {
                SectionTitle("Favourites") { nav.push(Route.Favs) }
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                    itemsIndexed(favTracks.take(15)) { i, t -> MediaCard(t.title, t.artist, t.artPath, { pc.play(favTracks, i) }) }
                }
            }
            if (playlists.isNotEmpty()) item {
                SectionTitle("Playlists")
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                    items(playlists, key = { it.id }) { p ->
                        val l = p.trackIds.mapNotNull { lib.byId[it] }
                        MediaCard(p.name, "${l.size} songs", albumArt(l), { nav.push(Route.Playlist(p.id)) })
                    }
                }
            }
            item {
                SectionTitle("Recently added")
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                    itemsIndexed(added) { i, t -> MediaCard(t.title, t.artist, t.artPath, { pc.play(added, i) }) }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

// ---------------- Songs ----------------
@Composable
fun SongsScreen() {
    val env = LocalEnv.current; val lib = env.lib; val pc = env.pc
    val tracks by lib.tracks.collectAsState()
    var sortIdx by rememberSaveable { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    val sorted = remember(tracks, sortIdx) { TrackOps.sort(tracks, SortBy.values()[sortIdx]) }
    Column(Modifier.fillMaxSize()) {
        Header("Songs") {
            Box {
                TextButton(onClick = { menu = true }) { Text(SortBy.values()[sortIdx].label, color = MvpRed) }
                DropdownMenu(menu, { menu = false }) {
                    SortBy.values().forEachIndexed { i, s -> DropdownMenuItem(text = { Text(s.label) }, onClick = { sortIdx = i; menu = false }) }
                }
            }
            IconButton(onClick = { pc.playShuffled(sorted) }) { Icon(Icons.Default.Shuffle, "Shuffle all") }
            TabActions()
        }
        if (sorted.isEmpty()) Empty("No supported audio files found in the selected folder.")
        else LazyColumn(Modifier.fillMaxSize()) { trackItems(sorted) }
    }
}

// ---------------- Albums / Artists ----------------
@Composable
fun AlbumsScreen() {
    val nav = LocalNav.current
    val tracks by LocalEnv.current.lib.tracks.collectAsState()
    val albums = remember(tracks) { TrackOps.albums(tracks) }
    Column(Modifier.fillMaxSize()) {
        Header("Albums") { TabActions() }
        if (albums.isEmpty()) Empty("No albums yet.")
        else LazyVerticalGrid(GridCells.Adaptive(150.dp), contentPadding = PaddingValues(12.dp)) {
            items(albums.keys.toList(), key = { it }) { a ->
                val l = albums.getValue(a)
                MediaCard(a, l.firstOrNull()?.artist ?: "", albumArt(l), { nav.push(Route.Album(a)) }, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
fun ArtistsScreen() {
    val nav = LocalNav.current
    val tracks by LocalEnv.current.lib.tracks.collectAsState()
    val artists = remember(tracks) { TrackOps.artists(tracks) }
    Column(Modifier.fillMaxSize()) {
        Header("Artists") { TabActions() }
        if (artists.isEmpty()) Empty("No artists yet.")
        else LazyColumn(Modifier.fillMaxSize()) {
            items(artists.keys.toList(), key = { it }) { a ->
                val l = artists.getValue(a)
                Row(Modifier.fillMaxWidth().clickable { nav.push(Route.Artist(a)) }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Art(albumArt(l), Modifier.size(52.dp), 128, 26.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(a, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${l.size} songs", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun PlayButtons(list: List<Track>) {
    val pc = LocalEnv.current.pc
    Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { pc.play(list, 0) }, enabled = list.isNotEmpty(),
            colors = ButtonDefaults.buttonColors(containerColor = MvpRed, contentColor = Color.White)) {
            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Play")
        }
        OutlinedButton(onClick = { pc.playShuffled(list) }, enabled = list.isNotEmpty()) {
            Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Shuffle")
        }
    }
}

@Composable
fun AlbumDetail(name: String) {
    val tracks by LocalEnv.current.lib.tracks.collectAsState()
    val list = remember(tracks, name) { TrackOps.albums(tracks)[name].orEmpty() }
    Column(Modifier.fillMaxSize()) {
        Header(name, back = true)
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Art(albumArt(list), Modifier.size(120.dp), 400, 12.dp)
                    Spacer(Modifier.width(16.dp))
                    Column { Text(list.firstOrNull()?.artist ?: "", color = MaterialTheme.colorScheme.onSurfaceVariant); Text("${list.size} songs") }
                }
                PlayButtons(list)
            }
            trackItems(list)
        }
    }
}

@Composable
fun ArtistDetail(name: String) {
    val nav = LocalNav.current
    val tracks by LocalEnv.current.lib.tracks.collectAsState()
    val list = remember(tracks, name) { TrackOps.artists(tracks)[name].orEmpty().sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo })) }
    val albums = remember(list) { list.groupBy { it.album } }
    Column(Modifier.fillMaxSize()) {
        Header(name, back = true)
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                PlayButtons(list)
                SectionTitle("Albums")
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                    items(albums.keys.toList()) { a -> MediaCard(a, "${albums.getValue(a).size} songs", albumArt(albums.getValue(a)), { nav.push(Route.Album(a)) }) }
                }
                SectionTitle("Songs")
            }
            trackItems(list)
        }
    }
}

// ---------------- Playlists / Favourites ----------------
@Composable
fun PlaylistsScreen() {
    val env = LocalEnv.current; val lib = env.lib; val nav = LocalNav.current
    val playlists by lib.playlists.collectAsState()
    val favs by lib.favourites.collectAsState()
    var creating by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Header("Playlists") {
            IconButton(onClick = { creating = true }) { Icon(Icons.Default.Add, "New playlist") }
            TabActions()
        }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                ListRow(Icons.Default.Favorite, "Favourites", "${favs.count { lib.byId.containsKey(it) }} songs") { nav.push(Route.Favs) }
            }
            items(playlists, key = { it.id }) { p ->
                ListRow(Icons.Default.QueueMusic, p.name, "${p.trackIds.count { lib.byId.containsKey(it) }} songs") { nav.push(Route.Playlist(p.id)) }
            }
        }
    }
    if (creating) NameDialog("New playlist", "", "Create", { lib.createPlaylist(it); creating = false }, { creating = false })
}

@Composable
fun ListRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MvpRed)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun FavouritesScreen() {
    val lib = LocalEnv.current.lib
    val tracks by lib.tracks.collectAsState()
    val favs by lib.favourites.collectAsState()
    val list = remember(tracks, favs) { tracks.filter { it.id in favs } }
    Column(Modifier.fillMaxSize()) {
        Header("Favourites", back = true)
        if (list.isEmpty()) Empty("No favourites yet. Tap ⋮ on a song and choose Add to favourites.")
        else LazyColumn(Modifier.fillMaxSize()) { item { PlayButtons(list) }; trackItems(list) }
    }
}

@Composable
fun PlaylistDetail(id: String) {
    val env = LocalEnv.current; val lib = env.lib; val nav = LocalNav.current
    val playlists by lib.playlists.collectAsState()
    val tracks by lib.tracks.collectAsState()
    val pl = playlists.find { it.id == id }
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf(false) }
    if (pl == null) { LaunchedEffect(Unit) { nav.pop() }; return }
    val list = remember(pl, tracks) { pl.trackIds.mapNotNull { lib.byId[it] } }
    fun move(from: Int, to: Int) {
        if (to !in list.indices) return
        val m = list.map { it.id }.toMutableList(); m.add(to, m.removeAt(from)); lib.setPlaylistTracks(id, m)
    }
    Column(Modifier.fillMaxSize()) {
        Header(pl.name, back = true) {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Rename") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { rename = true; menu = false })
                    DropdownMenuItem(text = { Text("Delete") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { delete = true; menu = false })
                }
            }
        }
        if (list.isEmpty()) Empty("This playlist is empty. Tap ⋮ on any song and choose Add to playlist.")
        else LazyColumn(Modifier.fillMaxSize()) {
            item { PlayButtons(list) }
            itemsIndexed(list, key = { i, t -> "${t.id}#$i" }) { i, t ->
                TrackRow(t, list, i, id) {
                    IconButton(onClick = { move(i, i - 1) }, enabled = i > 0) { Icon(Icons.Default.ArrowUpward, "Move up") }
                    IconButton(onClick = { move(i, i + 1) }, enabled = i < list.lastIndex) { Icon(Icons.Default.ArrowDownward, "Move down") }
                }
            }
        }
    }
    if (rename) NameDialog("Rename playlist", pl.name, "Save", { lib.renamePlaylist(id, it); rename = false }, { rename = false })
    if (delete) AlertDialog(
        onDismissRequest = { delete = false }, title = { Text("Delete playlist?") },
        text = { Text("\"${pl.name}\" will be deleted. Your songs are not affected.") },
        confirmButton = { TextButton(onClick = { delete = false; lib.deletePlaylist(id) }) { Text("Delete", color = MvpRed) } },
        dismissButton = { TextButton(onClick = { delete = false }) { Text("Cancel") } }
    )
}

// ---------------- Search ----------------
@Composable
fun SearchScreen() {
    val nav = LocalNav.current
    val tracks by LocalEnv.current.lib.tracks.collectAsState()
    var q by remember { mutableStateOf("") }
    val songs = remember(q, tracks) { TrackOps.search(tracks, q) }
    val artists = remember(q, tracks) { if (q.isBlank()) emptyList() else TrackOps.artists(tracks).filter { it.key.contains(q.trim(), true) }.toList() }
    val albums = remember(q, tracks) { if (q.isBlank()) emptyList() else TrackOps.albums(tracks).filter { it.key.contains(q.trim(), true) }.toList() }
    Column(Modifier.fillMaxSize()) {
        Header("Search", back = true)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true,
            placeholder = { Text("Songs, artists, albums") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = { if (q.isNotEmpty()) IconButton(onClick = { q = "" }) { Icon(Icons.Default.Close, "Clear") } })
        if (q.isBlank()) Empty("Search only inside your selected music folder.")
        else if (songs.isEmpty() && artists.isEmpty() && albums.isEmpty()) Empty("No results for \"$q\".")
        else LazyColumn(Modifier.fillMaxSize()) {
            if (artists.isNotEmpty()) {
                item { SectionTitle("Artists") }
                items(artists.take(5), key = { "ar" + it.first }) { (a, l) -> ListRow(Icons.Default.Person, a, "${l.size} songs") { nav.push(Route.Artist(a)) } }
            }
            if (albums.isNotEmpty()) {
                item { SectionTitle("Albums") }
                items(albums.take(5), key = { "al" + it.first }) { (a, l) -> ListRow(Icons.Default.Album, a, "${l.size} songs") { nav.push(Route.Album(a)) } }
            }
            if (songs.isNotEmpty()) {
                item { SectionTitle("Songs") }
                trackItems(songs.take(100))
            }
        }
    }
}

// ---------------- Settings ----------------
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val lib = LocalEnv.current.lib
    val folder by lib.folder.collectAsState()
    val dark by lib.dark.collectAsState()
    val tracks by lib.tracks.collectAsState()
    val scanning by lib.scanning.collectAsState()
    val pick = rememberFolderPicker()
    var confirm by remember { mutableStateOf(false) }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Settings", back = true)
        SettingBlock("Music folder") {
            Text(folder?.let { android.net.Uri.decode(it.lastPathSegment ?: it.toString()) } ?: "None selected")
            Text("${tracks.size} songs indexed", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = pick) { Icon(Icons.Default.Folder, null); Spacer(Modifier.width(6.dp)); Text("Change") }
                OutlinedButton(onClick = { lib.rescan() }, enabled = !scanning) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text(if (scanning) "Scanning…" else "Rescan") }
            }
        }
        SettingBlock("Appearance") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Dark theme", Modifier.weight(1f))
                Switch(dark, { lib.setDark(it) }, colors = SwitchDefaults.colors(checkedTrackColor = MvpRed, checkedThumbColor = Color.White))
            }
        }
        SettingBlock("Library") {
            Text("Removes the song index, cached artwork and the selected folder. Playlists and favourites are kept. Your music files are never touched.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { confirm = true }) { Text("Clear library", color = MvpRed) }
        }
        SettingBlock("About") { Text("MVPify version $version") }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, title = { Text("Clear library?") },
        text = { Text("The song index and selected folder will be removed. You can pick a folder again at any time.") },
        confirmButton = { TextButton(onClick = { confirm = false; lib.clearLibrary() }) { Text("Clear", color = MvpRed) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
}

@Composable
fun SettingBlock(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = MvpRed, fontWeight = FontWeight.Bold)
        content()
    }
}
