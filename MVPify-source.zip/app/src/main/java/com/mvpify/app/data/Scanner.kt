package com.mvpify.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import java.io.File
import java.io.IOException
import java.security.MessageDigest

/** Recursively scans ONLY the user-selected SAF tree. Never touches MediaStore. */
object Scanner {
    private val EXT = setOf("mp3", "m4a", "aac", "flac", "ogg", "oga", "opus", "wav", "mka", "amr", "3gp", "mid", "midi")

    fun isAudio(name: String, mime: String?): Boolean =
        (mime != null && mime.startsWith("audio/")) || name.substringAfterLast('.', "").lowercase() in EXT

    fun scan(ctx: Context, root: Uri, previous: Map<String, Track>, onProgress: (Int) -> Unit): List<Track> {
        val out = ArrayList<Track>()
        walk(ctx, root, DocumentsContract.getTreeDocumentId(root), previous, out, onProgress, true)
        return out
    }

    private fun walk(
        ctx: Context, root: Uri, docId: String, previous: Map<String, Track>,
        out: ArrayList<Track>, onProgress: (Int) -> Unit, top: Boolean
    ) {
        val children = DocumentsContract.buildChildDocumentsContractUri(root, docId)
        val dirs = ArrayList<String>()
        val files = ArrayList<Triple<String, String, Long>>()
        try {
            val cursor = ctx.contentResolver.query(
                children,
                arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE, Document.COLUMN_LAST_MODIFIED),
                null, null, null
            )
            if (cursor == null) {
                if (top) throw IOException("Folder is not accessible")
                return
            }
            cursor.use {
                while (it.moveToNext()) {
                    val id = it.getString(0) ?: continue
                    val name = it.getString(1) ?: ""
                    val mime = it.getString(2)
                    val mod = if (it.isNull(3)) 0L else it.getLong(3)
                    if (mime == Document.MIME_TYPE_DIR) dirs.add(id)
                    else if (isAudio(name, mime)) files.add(Triple(id, name, mod))
                }
            }
        } catch (e: Exception) {
            if (top) throw e
            return
        }
        for ((id, name, mod) in files) {
            val uri = DocumentsContract.buildDocumentUriUsingTree(root, id).toString()
            val old = previous[uri]
            if (old != null && old.addedAt == (if (mod == 0L) old.addedAt else mod)) out.add(old)
            else out.add(readTrack(ctx, uri, name, if (mod == 0L) System.currentTimeMillis() else mod))
            onProgress(out.size)
        }
        for (d in dirs) walk(ctx, root, d, previous, out, onProgress, false)
    }

    private fun readTrack(ctx: Context, uri: String, name: String, modified: Long): Track {
        val fallbackTitle = name.substringBeforeLast('.')
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(ctx, Uri.parse(uri))
            fun meta(k: Int) = mmr.extractMetadata(k)?.trim()?.takeIf { it.isNotEmpty() }
            val art = mmr.embeddedPicture?.let { saveThumb(ctx, uri, it) }
            return Track(
                id = uri,
                title = meta(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: fallbackTitle,
                artist = meta(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?: meta(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST) ?: "Unknown Artist",
                album = meta(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "Unknown Album",
                durationMs = meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
                trackNo = meta(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER)?.substringBefore('/')?.toIntOrNull() ?: 0,
                addedAt = modified,
                fileName = name,
                artPath = art
            )
        } catch (e: Exception) {
            return Track(uri, fallbackTitle, "Unknown Artist", "Unknown Album", 0L, 0, modified, name, null)
        } finally {
            try { mmr.release() } catch (_: Exception) {}
        }
    }

    private fun saveThumb(ctx: Context, key: String, bytes: ByteArray): String? {
        try {
            val dir = File(ctx.filesDir, "art").apply { mkdirs() }
            val f = File(dir, md5(key) + ".jpg")
            if (!f.exists()) {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var s = 1
                while (bounds.outWidth / s > 800) s *= 2
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
                    ?: return null
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                bmp.recycle()
            }
            return f.absolutePath
        } catch (e: Exception) {
            return null
        }
    }

    private fun md5(s: String) = MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
