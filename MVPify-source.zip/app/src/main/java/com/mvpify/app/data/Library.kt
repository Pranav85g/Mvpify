package com.mvpify.app.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors

/** Single source of truth: index, favourites, playlists, recents, prefs. Stored locally only. */
class Library(private val app: Context) {
    private val prefs = app.getSharedPreferences("mvpify", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val saveDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    private val tracksFile = File(app.filesDir, "tracks.json")
    private val userFile = File(app.filesDir, "user.json")

    val tracks = MutableStateFlow<List<Track>>(emptyList())
    @Volatile var byId: Map<String, Track> = emptyMap(); private set
    val folder = MutableStateFlow(prefs.getString("folder", null)?.let { Uri.parse(it) })
    val scanning = MutableStateFlow(false)
    val scanCount = MutableStateFlow(0)
    val message = MutableStateFlow<String?>(null)
    val favourites = MutableStateFlow<Set<String>>(emptySet())
    val playlists = MutableStateFlow<List<Playlist>>(emptyList())
    val recents = MutableStateFlow<List<String>>(emptyList())
    val dark = MutableStateFlow(prefs.getBoolean("dark", true))
    val tapPlaysList = MutableStateFlow(prefs.getBoolean("tapList", false))

    init {
        scope.launch {
            loadTracks(); loadUser()
            val f = folder.value
            if (f != null && app.contentResolver.persistedUriPermissions.none { it.uri == f && it.isReadPermission }) {
                message.value = "Access to the music folder was lost. Please choose it again."
            } else if (f != null && tracks.value.isEmpty()) rescan()
        }
    }

    private fun publish(list: List<Track>) { byId = list.associateBy { it.id }; tracks.value = list }

    // ---- folder / scanning ----
    fun setFolder(uri: Uri) {
        try {
            app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            message.value = "Couldn't keep access to that folder. Try another folder."; return
        }
        val old = folder.value
        if (old != null && old != uri) {
            try { app.contentResolver.releasePersistableUriPermission(old, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
        prefs.edit().putString("folder", uri.toString()).apply()
        folder.value = uri
        if (old != uri) publish(emptyList())
        message.value = null
        rescan()
    }

    fun rescan() {
        val root = folder.value ?: return
        if (scanning.value) return
        scanning.value = true; scanCount.value = 0; message.value = null
        scope.launch {
            try {
                val found = Scanner.scan(app, root, byId) { scanCount.value = it }
                publish(found)
                saveTracks()
                if (found.isEmpty()) message.value = "No supported audio files were found in this folder."
            } catch (e: Exception) {
                message.value = "Can't read the music folder. It may have been moved, deleted or its access was revoked."
            } finally { scanning.value = false }
        }
    }

    fun clearLibrary() {
        folder.value?.let { try { app.contentResolver.releasePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
        prefs.edit().remove("folder").apply()
        folder.value = null; message.value = null
        publish(emptyList()); recents.value = emptyList()
        scope.launch { tracksFile.delete(); File(app.filesDir, "art").deleteRecursively() }
        saveUser()
    }

    fun setTapPlaysList(v: Boolean) { prefs.edit().putBoolean("tapList", v).apply(); tapPlaysList.value = v }
    fun setDark(v: Boolean) { prefs.edit().putBoolean("dark", v).apply(); dark.value = v }

    // ---- favourites / recents ----
    fun toggleFavourite(id: String) {
        favourites.value = favourites.value.let { if (id in it) it - id else it + id }; saveUser()
    }
    fun markPlayed(id: String) {
        recents.value = (listOf(id) + recents.value.filter { it != id }).take(50); saveUser()
    }

    // ---- playlists ----
    private fun update(f: (List<Playlist>) -> List<Playlist>) { playlists.value = f(playlists.value); saveUser() }
    fun createPlaylist(name: String): String {
        val id = UUID.randomUUID().toString()
        update { it + Playlist(id, name.trim().ifEmpty { "New playlist" }, emptyList()) }
        return id
    }
    fun renamePlaylist(id: String, name: String) = update { l -> l.map { if (it.id == id) it.copy(name = name.trim().ifEmpty { it.name }) else it } }
    fun deletePlaylist(id: String) = update { l -> l.filter { it.id != id } }
    fun addToPlaylist(pid: String, tid: String) = update { l -> l.map { if (it.id == pid && tid !in it.trackIds) it.copy(trackIds = it.trackIds + tid) else it } }
    fun removeFromPlaylist(pid: String, tid: String) = update { l -> l.map { if (it.id == pid) it.copy(trackIds = it.trackIds - tid) else it } }
    fun setPlaylistTracks(pid: String, ids: List<String>) = update { l -> l.map { if (it.id == pid) it.copy(trackIds = ids) else it } }

    // ---- persistence ----
    private fun saveTracks() {
        val arr = JSONArray()
        tracks.value.forEach {
            arr.put(JSONObject().put("id", it.id).put("t", it.title).put("a", it.artist).put("al", it.album)
                .put("d", it.durationMs).put("n", it.trackNo).put("m", it.addedAt).put("f", it.fileName).put("art", it.artPath ?: ""))
        }
        runCatching { tracksFile.writeText(arr.toString()) }
    }

    private fun loadTracks() {
        runCatching {
            if (!tracksFile.exists()) return
            val arr = JSONArray(tracksFile.readText())
            publish((0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Track(o.getString("id"), o.getString("t"), o.getString("a"), o.getString("al"), o.getLong("d"),
                    o.getInt("n"), o.getLong("m"), o.getString("f"), o.optString("art").takeIf { p -> p.isNotEmpty() && File(p).exists() })
            })
        }
    }

    private fun saveUser() {
        val fav = favourites.value.toList(); val rec = recents.value; val pls = playlists.value
        scope.launch(saveDispatcher) {
            runCatching {
                val o = JSONObject()
                o.put("fav", JSONArray(fav)); o.put("recents", JSONArray(rec))
                o.put("playlists", JSONArray().also { a ->
                    pls.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("tracks", JSONArray(it.trackIds))) }
                })
                userFile.writeText(o.toString())
            }
        }
    }

    private fun loadUser() {
        runCatching {
            if (!userFile.exists()) return
            val o = JSONObject(userFile.readText())
            fun strs(a: JSONArray) = (0 until a.length()).map { a.getString(it) }
            favourites.value = strs(o.getJSONArray("fav")).toSet()
            recents.value = strs(o.getJSONArray("recents"))
            val pa = o.getJSONArray("playlists")
            playlists.value = (0 until pa.length()).map {
                val p = pa.getJSONObject(it); Playlist(p.getString("id"), p.getString("name"), strs(p.getJSONArray("tracks")))
            }
        }
    }
}
