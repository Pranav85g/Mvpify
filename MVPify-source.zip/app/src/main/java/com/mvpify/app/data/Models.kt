package com.mvpify.app.data

data class Track(
    val id: String,          // document URI string (unique)
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val trackNo: Int,
    val addedAt: Long,
    val fileName: String,
    val artPath: String?
)

data class Playlist(val id: String, val name: String, val trackIds: List<String>)

enum class SortBy(val label: String) { TITLE("Title"), ARTIST("Artist"), ALBUM("Album"), DATE("Date added") }

object TrackOps {
    fun sort(list: List<Track>, by: SortBy): List<Track> = when (by) {
        SortBy.TITLE -> list.sortedBy { it.title.lowercase() }
        SortBy.ARTIST -> list.sortedWith(compareBy({ it.artist.lowercase() }, { it.album.lowercase() }, { it.trackNo }))
        SortBy.ALBUM -> list.sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo }, { it.title.lowercase() }))
        SortBy.DATE -> list.sortedByDescending { it.addedAt }
    }

    fun search(list: List<Track>, query: String): List<Track> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return list.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) ||
                it.album.lowercase().contains(q) || it.fileName.lowercase().contains(q)
        }
    }

    fun albums(list: List<Track>): Map<String, List<Track>> =
        list.groupBy { it.album }
            .mapValues { (_, v) -> v.sortedWith(compareBy({ it.trackNo }, { it.title.lowercase() })) }
            .toSortedMap(compareBy { it.lowercase() })

    fun artists(list: List<Track>): Map<String, List<Track>> =
        list.groupBy { it.artist }.toSortedMap(compareBy { it.lowercase() })

    fun formatTime(ms: Long): String {
        val s = (if (ms < 0) 0 else ms) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }
}
