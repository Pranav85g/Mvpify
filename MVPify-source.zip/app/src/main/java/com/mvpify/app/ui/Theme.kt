package com.mvpify.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val MvpRed = Color(0xFFE11D2E)

private val DarkScheme = darkColorScheme(
    primary = MvpRed, onPrimary = Color.White, secondary = MvpRed, onSecondary = Color.White,
    background = Color(0xFF0A0A0A), onBackground = Color.White,
    surface = Color(0xFF141414), onSurface = Color.White,
    surfaceVariant = Color(0xFF232323), onSurfaceVariant = Color(0xFFA6A6A6),
    surfaceContainer = Color(0xFF141414), surfaceContainerHigh = Color(0xFF1C1C1C),
    outline = Color(0xFF3A3A3A)
)
private val LightScheme = lightColorScheme(
    primary = MvpRed, onPrimary = Color.White, secondary = MvpRed, onSecondary = Color.White,
    background = Color.White, onBackground = Color(0xFF111111),
    surface = Color(0xFFF7F7F7), onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFEAEAEA), onSurfaceVariant = Color(0xFF666666),
    surfaceContainer = Color(0xFFF7F7F7), surfaceContainerHigh = Color(0xFFEFEFEF),
    outline = Color(0xFFCCCCCC)
)

@Composable
fun MvpTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
}
