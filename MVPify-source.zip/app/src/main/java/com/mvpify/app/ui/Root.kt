package com.mvpify.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.animation.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.mvpify.app.data.*

@Composable
fun rememberFolderPicker(): () -> Unit {
    val lib = LocalEnv.current.lib
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) lib.setFolder(uri) }
    return { launcher.launch(null) }
}

@Composable
fun Root() {
    val lib = LocalEnv.current.lib
    val folder by lib.folder.collectAsState()
    val dark by lib.dark.collectAsState()
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? android.app.Activity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark; c.isAppearanceLightNavigationBars = !dark
        }
    }
    MvpTheme(dark) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (folder == null) EmptyLibrary() else MainShell()
        }
    }
}

@Composable
fun EmptyLibrary() {
    val pick = rememberFolderPicker()
    val lib = LocalEnv.current.lib
    val msg by lib.message.collectAsState()
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        MvpLogo(112.dp)
        Spacer(Modifier.height(20.dp))
        Text("MVPify", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Your library is empty.\nChoose the folder that holds your music. MVPify only reads that folder, and everything stays on your phone.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        msg?.let { Spacer(Modifier.height(12.dp)); Text(it, color = MvpRed, textAlign = TextAlign.Center) }
        Spacer(Modifier.height(24.dp))
        Button(onClick = pick, colors = ButtonDefaults.buttonColors(containerColor = MvpRed, contentColor = Color.White)) {
            Icon(Icons.Default.Folder, null); Spacer(Modifier.width(8.dp)); Text("Select Music Folder")
        }
    }
}

@Composable
fun StatusBanner() {
    val env = LocalEnv.current; val lib = env.lib; val pc = env.pc
    val msg by lib.message.collectAsState()
    val scanning by lib.scanning.collectAsState()
    val count by lib.scanCount.collectAsState()
    val err by pc.error.collectAsState()
    val pick = rememberFolderPicker()
    if (scanning) {
        Column {
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = MvpRed)
            Text("Scanning… $count files", Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall)
        }
    } else if (msg != null) {
        Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(msg ?: "", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { lib.rescan() }) { Text("Rescan", color = MvpRed) }
                TextButton(onClick = pick) { Text("Change", color = MvpRed) }
            }
        }
    }
    if (err != null) Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(err ?: "", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = { pc.error.value = null }) { Text("OK", color = MvpRed) }
        }
    }
}

@Composable
fun MainShell() {
    val env = LocalEnv.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var stack by remember { mutableStateOf(listOf<Route>()) }
    var showNow by remember { mutableStateOf(false) }
    val nav = remember { Nav({ stack = stack + it }, { stack = stack.dropLast(1) }, { showNow = true }) }
    BackHandler(showNow) { showNow = false }
    BackHandler(!showNow && stack.isNotEmpty()) { stack = stack.dropLast(1) }

    CompositionLocalProvider(LocalNav provides nav) {
        Box(Modifier.fillMaxSize()) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    Column {
                        MiniPlayer()
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                            val items = listOf("Home" to Icons.Default.Home, "Songs" to Icons.Default.MusicNote, "Albums" to Icons.Default.Album,
                                "Artists" to Icons.Default.Person, "Playlists" to Icons.Default.QueueMusic)
                            items.forEachIndexed { i, (label, icon) ->
                                NavigationBarItem(
                                    selected = tab == i && stack.isEmpty(), onClick = { stack = emptyList(); tab = i },
                                    icon = { Icon(icon, label) }, label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                    colors = NavigationBarItemDefaults.colors(selectedIconColor = MvpRed, selectedTextColor = MvpRed,
                                        indicatorColor = MvpRed.copy(alpha = 0.18f))
                                )
                            }
                        }
                    }
                }
            ) { pad ->
                Column(Modifier.padding(pad).fillMaxSize()) {
                    StatusBanner()
                    Box(Modifier.weight(1f)) {
                        when (val r = stack.lastOrNull()) {
                            null -> when (tab) {
                                0 -> HomeScreen(); 1 -> SongsScreen(); 2 -> AlbumsScreen(); 3 -> ArtistsScreen(); else -> PlaylistsScreen()
                            }
                            is Route.Album -> AlbumDetail(r.name)
                            is Route.Artist -> ArtistDetail(r.name)
                            is Route.Playlist -> PlaylistDetail(r.id)
                            Route.Favs -> FavouritesScreen()
                            Route.Search -> SearchScreen()
                            Route.Settings -> SettingsScreen()
                        }
                    }
                }
            }
            AnimatedVisibility(showNow, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
                NowPlaying { showNow = false }
            }
        }
    }
}
