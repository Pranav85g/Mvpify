package com.mvpify.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.mvpify.app.data.*
import kotlin.math.roundToInt

private data class QItem(val key: String, val id: String)

private val RowHeight = 64.dp

@Composable
fun QueueScreen(onBack: () -> Unit) {
    val env = LocalEnv.current; val lib = env.lib; val pc = env.pc
    val queue by pc.queue.collectAsState()
    val curIdx by pc.currentIndex.collectAsState()
    val tracks by lib.tracks.collectAsState()
    var showPicker by remember { mutableStateOf(false) }

    val upcoming = remember(queue, curIdx) {
        val seen = HashMap<String, Int>()
        queue.drop(curIdx + 1).map { id ->
            val n = seen.getOrDefault(id, 0); seen[id] = n + 1
            QItem("$id#$n", id)
        }
    }
    val local = remember { mutableStateListOf<QItem>().apply { addAll(upcoming) } }
    var dragStart by remember { mutableIntStateOf(-1) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(upcoming) { if (dragStart < 0) { local.clear(); local.addAll(upcoming) } }

    val rowH = with(LocalDensity.current) { RowHeight.toPx() }
    fun targetNow(): Int =
        if (dragStart < 0) -1 else (dragStart + (dragOffset / rowH).roundToInt()).coerceIn(0, maxOf(local.lastIndex, 0))
    val target = targetNow()

    fun commit() {
        val from = dragStart; val to = targetNow()
        if (from >= 0 && to >= 0 && from != to) {
            local.add(to, local.removeAt(from))
            pc.moveInQueue(curIdx + 1 + from, curIdx + 1 + to)
        }
        dragStart = -1; dragOffset = 0f
    }

    val now = queue.getOrNull(curIdx)?.let { lib.byId[it] }
    val recents by lib.recents.collectAsState()
    val hist = remember(queue, curIdx) { queue.take(curIdx) }
    val rec = remember(recents, tracks, now) {
        if (hist.isNotEmpty()) emptyList() else recents.mapNotNull { lib.byId[it] }.filter { it.id != now?.id }.take(10)
    }
    val histCount = if (hist.isNotEmpty()) hist.size else rec.size
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) { if (histCount > 0) listState.scrollToItem(1 + histCount) }
    val bg = MaterialTheme.colorScheme.background
    val sub = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        Modifier.fillMaxSize().background(bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .statusBarsPadding().navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Queue", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { showPicker = true }) { Icon(Icons.Default.Add, null, tint = MvpRed); Spacer(Modifier.width(4.dp)); Text("Add songs", color = MvpRed) }
            TextButton(onClick = { pc.clearUpcoming() }, enabled = local.isNotEmpty()) { Text("Clear") }
        }
        LazyColumn(Modifier.fillMaxSize(), state = listState, userScrollEnabled = dragStart < 0) {
            if (histCount > 0) {
                item(key = "hist-h") {
                    Text(if (hist.isNotEmpty()) "Previously played" else "Recently played", Modifier.padding(16.dp, 8.dp),
                        style = MaterialTheme.typography.labelLarge, color = sub)
                }
                if (hist.isNotEmpty()) {
                    itemsIndexed(hist, key = { i, _ -> "h$i" }) { i, id -> HistRow(lib.byId[id]) { pc.skipTo(i) } }
                } else {
                    itemsIndexed(rec, key = { i, _ -> "r$i" }) { _, t -> HistRow(t) { pc.tap(listOf(t), 0, false) } }
                }
            }
            item(key = "now-h") { Text("Now playing", Modifier.padding(16.dp, 8.dp), style = MaterialTheme.typography.labelLarge, color = sub) }
            item(key = "now") {
                Row(Modifier.fillMaxWidth().height(RowHeight).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Art(now?.artPath, Modifier.size(44.dp), 128)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(now?.title ?: "Nothing playing", color = MvpRed, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(now?.artist ?: "", style = MaterialTheme.typography.bodySmall, color = sub, maxLines = 1)
                    }
                }
            }
            item(key = "next-h") {
                Text("Next in queue  •  hold ≡ and drag to reorder", Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp),
                    style = MaterialTheme.typography.labelLarge, color = sub)
            }
            if (local.isEmpty()) item(key = "empty") {
                Text("Nothing queued. Tap \"Add songs\", or use ⋮ → Add to queue on any song. When the queue ends, playback stops.",
                    Modifier.padding(16.dp), color = sub)
            }
            itemsIndexed(local, key = { _, q -> q.key }) { i, q ->
                val t = lib.byId[q.id]
                val dragging = i == dragStart
                val shift = when {
                    dragStart < 0 -> 0f
                    dragging -> dragOffset
                    dragStart < target && i in (dragStart + 1)..target -> -rowH
                    dragStart > target && i in target until dragStart -> rowH
                    else -> 0f
                }
                Row(
                    Modifier.fillMaxWidth().height(RowHeight).zIndex(if (dragging) 1f else 0f)
                        .graphicsLayer { translationY = shift }
                        .background(if (dragging) MaterialTheme.colorScheme.surfaceContainerHigh else bg)
                        .clickable { pc.skipTo(curIdx + 1 + i) }.padding(start = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Art(t?.artPath, Modifier.size(44.dp), 128)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t?.title ?: "Unavailable file", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(t?.artist ?: "", style = MaterialTheme.typography.bodySmall, color = sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { pc.removeFromQueue(curIdx + 1 + i) }) { Icon(Icons.Default.Close, "Remove") }
                    Icon(
                        Icons.Default.DragHandle, "Reorder",
                        Modifier.size(52.dp).padding(14.dp).pointerInput(q.key) {
                            detectDragGestures(
                                onDragStart = { dragStart = local.indexOfFirst { it.key == q.key }; dragOffset = 0f },
                                onDrag = { change, amount -> change.consume(); dragOffset += amount.y },
                                onDragEnd = { commit() },
                                onDragCancel = { dragStart = -1; dragOffset = 0f }
                            )
                        },
                        tint = sub
                    )
                }
            }
        }
    }
    if (showPicker) SongPicker(tracks) { showPicker = false }
}

@Composable
private fun SongPicker(tracks: List<Track>, onClose: () -> Unit) {
    val env = LocalEnv.current; val lib = env.lib; val pc = env.pc
    var q by remember { mutableStateOf("") }
    val selected = remember { mutableStateListOf<String>() }
    val list = remember(q, tracks) { if (q.isBlank()) TrackOps.sort(tracks, SortBy.TITLE) else TrackOps.search(tracks, q) }
    BackHandler(true) { onClose() }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .statusBarsPadding().navigationBarsPadding()
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close") }
            Text("Add songs to queue", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true,
            placeholder = { Text("Search songs") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        LazyColumn(Modifier.weight(1f)) {
            items(list, key = { it.id }) { t ->
                Row(
                    Modifier.fillMaxWidth().clickable { if (t.id in selected) selected.remove(t.id) else selected.add(t.id) }
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(t.id in selected, null, colors = CheckboxDefaults.colors(checkedColor = MvpRed))
                    Spacer(Modifier.width(8.dp))
                    Art(t.artPath, Modifier.size(44.dp), 128)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(t.artist, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                }
            }
        }
        Button(
            onClick = { pc.addAllToQueue(selected.mapNotNull { lib.byId[it] }); onClose() },
            enabled = selected.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MvpRed, contentColor = Color.White)
        ) { Text(if (selected.isEmpty()) "Select songs" else "Add ${selected.size} to queue") }
    }
}

@Composable
private fun HistRow(t: Track?, onClick: () -> Unit) {
    val sub = MaterialTheme.colorScheme.onSurfaceVariant
    Row(Modifier.fillMaxWidth().height(RowHeight).clickable(onClick = onClick).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Art(t?.artPath, Modifier.size(44.dp), 128)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t?.title ?: "Unavailable file", color = sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t?.artist ?: "", style = MaterialTheme.typography.bodySmall, color = sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.History, null, tint = sub)
    }
}
