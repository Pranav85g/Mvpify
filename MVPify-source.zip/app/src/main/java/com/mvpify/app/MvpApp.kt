package com.mvpify.app

import android.app.Application
import com.mvpify.app.data.Library
import com.mvpify.app.playback.PlayerController

class MvpApp : Application() {
    lateinit var lib: Library; private set
    val player: PlayerController by lazy { PlayerController(this, lib) }
    override fun onCreate() { super.onCreate(); lib = Library(this) }
}
