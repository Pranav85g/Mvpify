package com.mvpify.app.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.mvpify.app.data.Library
import com.mvpify.app.data.Track
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import kotlin.random.Random

/** UI-side handle to the PlaybackService (via MediaController). Must be created/used on the main thread. */
class PlayerController(private val ctx: Context, private val lib: Library) {
    private var controller: MediaController? = null
    private val pending = ArrayList<(MediaController) -> Unit>()

    val isPlaying = MutableStateFlow(false)
    val currentId = MutableStateFlow<String?>(null)
    val shuffle = MutableStateFlow(false)
    val repeat = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val queue = MutableStateFlow<List<String>>(emptyList())
    val error = MutableStateFlow<String?>(null)

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { this@PlayerController.isPlaying.value = isPlaying }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentId.value = mediaItem?.mediaId
            mediaItem?.mediaId?.let { lib.markPlayed(it) }
        }
        override fun onTimelineChanged(timeline: Timeline, reason: Int) { controller?.let { syncQueue(it) } }
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) { shuffle.value = shuffleModeEnabled }
        override fun onRepeatModeChanged(repeatMode: Int) { repeat.value = repeatMode }
        override fun onPlayerError(e: PlaybackException) {
            error.value = "Couldn't play a file (corrupted, unsupported or no longer accessible). Skipped."
            controller?.let { if (it.hasNextMediaItem()) { it.seekToNextMediaItem(); it.prepare(); it.play() } }
        }
    }

    init {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(listener)
                isPlaying.value = c.isPlaying; currentId.value = c.currentMediaItem?.mediaId
                shuffle.value = c.shuffleModeEnabled; repeat.value = c.repeatMode
                syncQueue(c)
                pending.forEach { it(c) }; pending.clear()
            } catch (e: Exception) { error.value = "Couldn't start the audio player." }
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun syncQueue(c: MediaController) {
        queue.value = (0 until c.mediaItemCount).map { c.getMediaItemAt(it).mediaId }
    }

    private fun withPlayer(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pending.add(block)
    }

    private fun item(t: Track) = MediaItem.Builder()
        .setMediaId(t.id)
        .setUri(t.id)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album)
                .setArtworkUri(t.artPath?.let { Uri.fromFile(File(it)) }).build()
        ).build()

    fun play(list: List<Track>, index: Int) = withPlayer { c ->
        if (list.isEmpty()) return@withPlayer
        c.setMediaItems(list.map { item(it) }, index.coerceIn(0, list.lastIndex), 0L)
        c.prepare(); c.play()
    }

    fun playShuffled(list: List<Track>) = withPlayer { c ->
        if (list.isEmpty()) return@withPlayer
        c.shuffleModeEnabled = true
        c.setMediaItems(list.map { item(it) }, Random.nextInt(list.size), 0L)
        c.prepare(); c.play()
    }

    fun playNext(t: Track) = withPlayer { c ->
        if (c.mediaItemCount == 0) { c.setMediaItem(item(t)); c.prepare(); c.play() }
        else c.addMediaItem(c.currentMediaItemIndex + 1, item(t))
    }

    fun addToQueue(t: Track) = withPlayer { c ->
        if (c.mediaItemCount == 0) { c.setMediaItem(item(t)); c.prepare(); c.play() } else c.addMediaItem(item(t))
    }

    fun toggle() = withPlayer { c -> if (c.isPlaying) c.pause() else { if (c.playbackState == Player.STATE_IDLE) c.prepare(); c.play() } }
    fun next() = withPlayer { it.seekToNextMediaItem() }
    fun previous() = withPlayer { it.seekToPrevious() }
    fun seekTo(ms: Long) = withPlayer { it.seekTo(ms) }
    fun skipTo(index: Int) = withPlayer { it.seekTo(index, 0L) }
    fun removeFromQueue(index: Int) = withPlayer { if (index in 0 until it.mediaItemCount) it.removeMediaItem(index) }
    fun toggleShuffle() = withPlayer { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    fun cycleRepeat() = withPlayer {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun position(): Long = controller?.currentPosition ?: 0L
    fun duration(): Long = controller?.duration?.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L
}
