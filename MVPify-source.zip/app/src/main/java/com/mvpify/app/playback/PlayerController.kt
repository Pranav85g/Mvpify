package com.mvpify.app.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.mvpify.app.data.Library
import com.mvpify.app.data.Track
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/**
 * UI-side handle to PlaybackService. The player's playlist IS the queue:
 *  - items before the current index = history (so "Previous" works)
 *  - items after the current index = "Next in queue" (only what the user chose)
 * Must be created/used on the main thread.
 */
class PlayerController(private val ctx: Context, private val lib: Library) {
    private var controller: MediaController? = null
    private val pending = ArrayList<(MediaController) -> Unit>()

    val isPlaying = MutableStateFlow(false)
    val currentId = MutableStateFlow<String?>(null)
    val currentIndex = MutableStateFlow(0)
    val shuffle = MutableStateFlow(false)
    val repeat = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val queue = MutableStateFlow<List<String>>(emptyList())
    val error = MutableStateFlow<String?>(null)

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { this@PlayerController.isPlaying.value = isPlaying }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentId.value = mediaItem?.mediaId
            controller?.let { currentIndex.value = it.currentMediaItemIndex }
            mediaItem?.mediaId?.let { lib.markPlayed(it) }
        }
        override fun onTimelineChanged(timeline: Timeline, reason: Int) { controller?.let { syncQueue(it) } }
        override fun onRepeatModeChanged(repeatMode: Int) { repeat.value = repeatMode }
        override fun onPlayerError(e: PlaybackException) {
            error.value = "Couldn't play a file (corrupted, unsupported or no longer accessible). Skipped."
            controller?.let { if (it.hasNextMediaItem()) { it.seekToNextMediaItem(); it.prepare(); it.play() } }
        }
    }

    init {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(listener)
                isPlaying.value = c.isPlaying; currentId.value = c.currentMediaItem?.mediaId
                repeat.value = c.repeatMode
                syncQueue(c)
                pending.forEach { it(c) }; pending.clear()
            } catch (e: Exception) { error.value = "Couldn't start the audio player." }
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun syncQueue(c: MediaController) {
        queue.value = (0 until c.mediaItemCount).map { c.getMediaItemAt(it).mediaId }
        currentIndex.value = c.currentMediaItemIndex
    }

    private fun withPlayer(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pending.add(block)
    }

    private fun item(t: Track) = MediaItem.Builder()
        .setMediaId(t.id)
        .setUri(t.id)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album)
                .setArtworkUri(t.artPath?.let { Uri.fromFile(File(it)) }).build()
        ).build()

    /** Replace the whole queue with [list] (used by explicit Play / Shuffle buttons). */
    fun play(list: List<Track>, index: Int) = withPlayer { c ->
        if (list.isEmpty()) return@withPlayer
        shuffle.value = false
        c.setMediaItems(list.map { item(it) }, index.coerceIn(0, list.lastIndex), 0L)
        c.prepare(); c.play()
    }

    fun playShuffled(list: List<Track>) = withPlayer { c ->
        if (list.isEmpty()) return@withPlayer
        shuffle.value = true
        c.setMediaItems(list.shuffled().map { item(it) }, 0, 0L)
        c.prepare(); c.play()
    }

    /**
     * Tap on a single song. Default: play ONLY that song right now; the songs the user already
     * queued stay queued, the previous song stays in history. If [wholeList] is true, queue the list.
     */
    fun tap(list: List<Track>, index: Int, wholeList: Boolean) {
        if (wholeList) { play(list, index); return }
        val t = list.getOrNull(index) ?: return
        withPlayer { c ->
            if (c.mediaItemCount == 0) {
                c.setMediaItem(item(t)); c.prepare(); c.play(); return@withPlayer
            }
            val idx = c.currentMediaItemIndex
            c.addMediaItem(idx + 1, item(t))
            c.seekTo(idx + 1, 0L)
            c.prepare(); c.play()
            val cur = c.currentMediaItemIndex
            if (cur > 30) c.removeMediaItems(0, cur - 20) // keep history short
        }
    }

    fun playNext(t: Track) = withPlayer { c ->
        if (c.mediaItemCount == 0) { c.setMediaItem(item(t)); c.prepare(); c.play() }
        else c.addMediaItem(c.currentMediaItemIndex + 1, item(t))
    }

    fun addToQueue(t: Track) = addAllToQueue(listOf(t))

    fun addAllToQueue(list: List<Track>) = withPlayer { c ->
        if (list.isEmpty()) return@withPlayer
        if (c.mediaItemCount == 0) {
            c.setMediaItems(list.map { item(it) }); c.prepare(); c.play()
        } else c.addMediaItems(list.map { item(it) })
    }

    fun moveInQueue(from: Int, to: Int) = withPlayer { c ->
        if (from in 0 until c.mediaItemCount && to in 0 until c.mediaItemCount) c.moveMediaItem(from, to)
    }

    fun clearUpcoming() = withPlayer { c ->
        val from = c.currentMediaItemIndex + 1
        if (from < c.mediaItemCount) c.removeMediaItems(from, c.mediaItemCount)
    }

    fun toggle() = withPlayer { c ->
        if (c.isPlaying) c.pause()
        else {
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(c.currentMediaItemIndex, 0L)
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }
    fun next() = withPlayer { it.seekToNextMediaItem() }
    fun previous() = withPlayer { it.seekToPrevious() }
    fun seekTo(ms: Long) = withPlayer { it.seekTo(ms) }
    fun skipTo(index: Int) = withPlayer { it.seekTo(index, 0L) }
    fun removeFromQueue(index: Int) = withPlayer { if (index in 0 until it.mediaItemCount) it.removeMediaItem(index) }

    /** Shuffle turns on = randomise the songs still to come (so the queue list shows the real order). */
    fun toggleShuffle() = withPlayer { c ->
        val on = !shuffle.value
        shuffle.value = on
        if (on) {
            val from = c.currentMediaItemIndex + 1
            val n = c.mediaItemCount
            if (n - from >= 2) c.replaceMediaItems(from, n, (from until n).map { c.getMediaItemAt(it) }.shuffled())
        }
    }

    fun cycleRepeat() = withPlayer {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun position(): Long = controller?.currentPosition ?: 0L
    fun duration(): Long = controller?.duration?.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L
}
