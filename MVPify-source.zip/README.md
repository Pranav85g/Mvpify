# MVPify – offline folder-based music player (Android 14+)

Kotlin · Jetpack Compose (Material 3) · Media3 ExoPlayer + MediaSession · Storage Access Framework. No internet permission, no analytics, no accounts.

## Get the APK (no Android Studio needed)
1. Create a new **private** GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab → *Build MVPify APK* → it runs on every push (or press *Run workflow*).
3. When it finishes, open the run → **Artifacts** → download `MVPify-debug-apk` → unzip → `app-debug.apk`.
4. Copy it to your phone, open it, allow "install unknown apps" for your file manager/browser.

## Or build locally
Open this folder in Android Studio (Ladybug or newer, JDK 17). It creates the Gradle wrapper and syncs; then **Build → Build APK(s)**, or:
`gradle assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`

## Notes
- minSdk/targetSdk 34 (Android 14+). Notification permission is requested for media controls.
- Library index, favourites, playlists and recents are stored as JSON in the app's private storage (not Room, to keep the build simple).
- Unit tests: `gradle test` (sorting, search, grouping, time formatting).
